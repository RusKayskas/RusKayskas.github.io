export function createdCookieWizard(
  bandwidth,
  tariff,
  billingCycle,
  billingType,
) {
  const cookie = {
    type: 'tunnel',
    productId: '51',
    bandwidth: bandwidth,
    tariff: tariff,
    currency: 'USD',
    billingCycle: billingCycle,
    billingType: billingType,
    location: 'hk',
  };
  const cookieString = JSON.stringify(cookie);
  document.cookie = `newWizard=${cookieString}; path=/; domain=.ddos-guard.net`;
}
