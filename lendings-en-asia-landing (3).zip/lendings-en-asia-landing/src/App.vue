<template>
  <VueAsia />
</template>

<script setup>
  import VueAsia from './page/asia/index.vue';
</script>
