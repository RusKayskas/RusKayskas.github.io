export function formatPrice(price, currency = 'RUB') {
  let format = 'ru-RU';

  if (currency !== 'RUB') {
    format = 'en-US';
  }

  return price.toLocaleString(format);
}
/**
 * Форматирование с formatPrice, но с указанием символа валюты.
 * */
export function formatPriceString(price, currency = 'RUB') {
  const formattedPrice = formatPrice(price, currency);
  const currencyDir = {
    RUB: '₽',
    USD: '$',
    EUR: '€',
  };

  if (currency === 'USD') {
    return currencyDir[currency] + formattedPrice;
  }

  return `${formattedPrice} ${currencyDir[currency]}`;
}
