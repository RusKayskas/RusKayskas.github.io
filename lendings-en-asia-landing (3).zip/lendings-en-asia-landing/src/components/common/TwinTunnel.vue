<template>
  <UiSection id="twintunnel" class="twin-tunnel">
    <template #content>
      <div ref="container" class="fader">
        <div
          v-for="(slide, index) in slides"
          :key="index"
          class="fader__slide twin-tunnel__slide"
          :style="{ opacity: opacities[index] }"
        >
          <div class="twin-tunnel__text">
            <div class="twin-tunnel__head">
              <p class="twin-tunnel__head-title title">{{ slide.title }}</p>
              <p class="twin-tunnel__head-description title">
                {{ slide.description }}
              </p>
            </div>
            <div class="twin-tunnel__content">
              <p class="twin-tunnel__content-title title">
                {{ slide.detailsTitle }}
              </p>
              <p class="twin-tunnel__content-description">
                {{ slide.detailsText }}
              </p>
              <UiButton
                v-if="slide.button"
                id="btn-lp-asia-tt-screen"
                tag="a"
                href="#configurator"
                class="twin-tunnel__content-button"
                :title="slide.button"
              />
            </div>
          </div>

          <div class="twin-tunnel__img">
            <img
              :src="require(`@/assets/images/asia/twinSlider/${slide.img}`)"
              :alt="$t(slide.title)"
            />
          </div>
        </div>
        <div class="slider-nav slider-nav--white">
          <UiButton
            icon="icons/slider/arrLeft.svg"
            :class="[
              'ui-button--arrow arrow arrow--left',
              { 'arrow--disabled': disabledRightArrow },
            ]"
            @action="slider.prev()"
          />
          <div
            v-if="slider"
            class="slider__pagination slider__pagination--white"
          >
            <button
              v-for="(_slide, index) in dotHelper"
              @click="slider.moveToIdx(index)"
              :class="['slider__pagination-dot', addClassToDots(index)]"
              :key="index"
            />
          </div>
          <UiButton
            v-if="slider"
            icon="icons/slider/arrRight.svg"
            :class="[
              'ui-button--arrow arrow arrow--right',
              { 'arrow--disabled': disabledLefttArrow },
            ]"
            @action="slider.next()"
          />
        </div>
      </div>
    </template>
  </UiSection>
</template>

<script setup>
  import { ref, computed, defineProps } from 'vue';
  import { useKeenSlider } from 'keen-slider/vue.es';
  import { UiSection, UiButton } from '@/components/UI';
  const props = defineProps({
    twinTunnel: {
      type: Object,
      required: true,
    },
  });
  const slides = ref(props.twinTunnel.slides);
  const current = ref(0);
  const opacities = ref([]);
  const [container, slider] = useKeenSlider({
    initial: current.value,
    slides: slides.value.length,
    loop: true,
    defaultAnimation: {
      duration: 0,
    },
    detailsChanged: (s) => {
      opacities.value = s.track.details.slides.map((slide) => slide.portion);
    },
    slideChanged: (s) => {
      current.value = s.track.details.rel;
    },
  });
  const dotHelper = computed(() =>
    slider.value
      ? [...Array(slider.value.track.details.slides.length).keys()]
      : [],
  );

  const disabledRightArrow = computed(() => {
    return current.value === 0;
  });
  const disabledLefttArrow = computed(() => {
    return current.value === slider._rawValue.track.details.slides.length - 1;
  });
  const addClassToDots = (index) => {
    return {
      dot: true,
      'slider__pagination-dot--is-active': current.value === index,
    };
  };
</script>

<style lang="scss">
  .ui-slider {
    max-width: 100%;
  }
  .twin-tunnel {
    padding: 60px 0;
    @include media-xs-min {
      padding: 100px 0;
    }
    &.s-gradient::before {
      right: -224.096px;
      bottom: -258.801px;
      border-radius: 527.348px;
      opacity: 0.5;
      background: linear-gradient(
        298deg,
        rgba(233, 100, 255, 0.63) 32.11%,
        #006be5 80.9%
      );

      filter: blur(200px);
      width: 527.348px;
      height: 463.615px;
      top: auto;
      transform: translate(0);
      left: auto;
      @include media-xs-min {
        width: 935px;
        right: -499px;
        bottom: -411px;
        height: 822px;
      }
    }
    &::after {
      content: '';
      position: absolute;
      display: block;
      width: 443.78px;
      height: 390.147px;
      left: -236.89px;
      top: -102.43px;
      border-radius: 443.78px;
      opacity: 0.5;
      background: linear-gradient(
        298deg,
        rgba(233, 100, 255, 0.63) 32.11%,
        #006be5 80.9%
      );
      filter: blur(94.9262924194336px);
      z-index: 1;
      @include media-xs-min {
        width: 935px;
        height: 822px;
        border-radius: 935px;
        top: -296px;
        left: -505px;
      }
    }
    .ui-slider {
      border-radius: 0;
    }
    .ui-slider-wrapper {
      padding: 0;
      margin: 0;
    }
    .slider__pagination {
      margin: 0 20px;
      @include media-xs-min {
        margin-top: 0;
      }
    }
    .slider-nav {
      position: absolute;
      bottom: 0;
      display: flex;
      align-items: center;
      left: 50%;
      width: 100%;
      justify-content: space-between;
      transform: translateX(-50%);
      @include media-xs-min {
        transform: translateX(0);
        left: 0;
        width: fit-content;
        justify-content: flex-start;
      }
    }
    .slider-nav .arrow {
      position: relative;
      bottom: auto;
      transform: translateY(0);
      @include media-xs-min {
        position: relative;
        transform: translateY(0);
      }
    }
    &__slide {
      text-align: left;
      @include media-xs-min {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
      }
    }
    &__text {
      margin-bottom: 10px;
      @include media-xs-min {
        width: 55%;
        margin-bottom: 0;
      }
    }
    &__head {
      margin-bottom: 20px;
      @include media-xs-min {
        margin-bottom: 50px;
      }
      &-title {
        @include text(h2, normal, normal);
        @include media-xs-min {
          line-height: 55px;
        }
      }
      &-description {
        @include text(paragraph, small, bold);
        font-weight: 600 !important;
        color: #66ccff;
        @include media-xs-min {
          @include text(paragraph, large, bold);
        }
      }
    }
    &__content {
      &-title {
        @include text(h3, normal, bold);
        margin-bottom: 5px;
        @include media-xs-min {
          @include text(paragraph, extralarge, bold);
        }
      }
      &-description {
        @include text(paragraph, small, normal);
        @include media-xs-min {
          max-width: 454px;
          @include text(paragraph, normal, normal);
          line-height: 25px;
        }
      }
      &-button {
        margin-top: 25px;
        @include media-sm-min {
          min-width: 140px;
          padding: 10px 15px;
          font-size: 18px;
        }
      }
    }
    &__img {
      display: flex;
      padding: 22px;
      align-items: center;
      justify-content: center;
      @include media-xs-min {
        max-width: 676px;
      }
      img {
        max-width: 302px;
        @include media-xs-min {
          max-width: unset;
        }
      }
    }
  }
  .fader {
    height: 570px;
    position: relative;
    overflow: hidden;
    @include media-sm-min {
      height: 400px;
    }
  }

  .fader__slide {
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
  }
</style>
