<!-- eslint-disable max-len -->
<template>
  <section id="banner" class="asia-banner s-gradient">
    <div class="asia-banner-wrapper container">
      <div class="asia-banner__text">
        <h1 class="asia-banner__title title title--big">
          {{ banner.title }}
        </h1>
        <p class="asia-banner__details title">
          {{ banner.details }}
        </p>
        <UiButton
          tag="a"
          class="asia-banner__ui-button"
          :title="banner.btn.title"
          href="#configurator"
          :id="banner.btn.id"
        />
      </div>
    </div>
    <div class="asia-banner__media">
      <ul class="asia-banner__list">
        <li
          v-for="(item, index) in banner.list"
          :key="index"
          class="asia-banner__list-item"
          v-html="item"
        />
      </ul>
      <picture class="asia-banner__picture">
        <source
          media="(min-width: 1024px)"
          srcset="@/assets/images/asia/banner/banner.png"
        />
        <img
          src="@/assets/images/asia/banner/bg-banner-mobile.png"
          loading="lazy"
          alt="image"
        />
      </picture>
    </div>
  </section>
</template>

<script setup>
  import { UiButton } from '@/components/UI';
  defineProps({
    banner: {
      type: Object,
      required: true,
    },
  });
</script>

<style lang="scss">
  .asia-banner {
    padding-top: 60px;
    @include media-sm-min {
      padding-top: 0;
      min-height: 500px;
    }
    &.s-gradient::before {
      left: -283.652px;
      top: -105.5px;
      border-radius: 489px;
      opacity: 0.7;
      background: linear-gradient(
        327deg,
        rgba(233, 100, 255, 0.63) 33.1%,
        #006be5 68.04%
      );
      width: 489px;
      height: 326px;
      filter: blur(90px);
      transform: translateX(0);
      @include media-sm-min {
        left: -309px;
        top: -202px;
        width: 661px;
        height: 440px;
        border-radius: 661px;
        background: linear-gradient(
          327deg,
          rgba(233, 100, 255, 0.63) 33.1%,
          #006be5 68.04%
        );
        filter: blur(140px);
      }
    }
    &__title {
      font-size: 25px;
      line-height: 30px;
      margin-bottom: 10px;
      @include media-sm-min {
        line-height: 60px !important;
      }
    }
    &__text {
      position: relative;
      z-index: 3;
      display: block;
      text-align: center;
      @include media-sm-min {
        text-align: left;
        padding: 120px 0;
        max-width: 50%;
        line-height: 30px;
      }
    }
    &__ui-button {
      margin-top: 30px;
      width: 170px;
      min-width: 170px;
      @include media-xs-min {
        margin-top: 40px;
      }
      @include media-sm-min {
        margin-top: 50px;
      }
    }
    &__media {
      height: 437px;
      margin-top: -30px;
      position: relative;
      z-index: 2;
      @include media-sm-min {
        position: absolute;
        margin-top: 0;
        height: 100%;
        top: 0;
        right: 0;
        width: 50%;
        display: flex;
        justify-content: flex-end;
      }
    }
    &__picture {
      position: absolute;
      right: 0;
      top: 0;
      @include media-sm-min {
        position: relative;
      }
      img {
        height: 100%;
        object-fit: unset;
      }
    }
    &__list {
      padding-top: 142px;
      padding-right: 180px;
      position: relative;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      text-align: right;
      @include media-sm-min {
        padding-right: 0;
        padding-top: 100px;
      }
      &-item {
        @include media-sm-min {
          margin-right: -20px;
        }
        .details {
          @include text(paragraph, smaller, normal);
          white-space: nowrap;
          font-style: normal;
          line-height: 20px;
          @include media-sm-min {
            @include text(paragraph, small, normal);
          }
        }
        &:first-child {
          margin-bottom: 18px;
          @include media-sm-min {
            margin-bottom: 84px;
          }
        }
        &:nth-child(2) {
          margin-bottom: 15px;
          @include media-sm-min {
            margin-right: 0;
            margin-bottom: 85px;
          }
          .title {
            @include text(paragraph, large, bold);
            @include media-sm-min {
              @include text(paragraph, big, bold);
            }
          }
        }
      }
      .title {
        @include text(paragraph, small, bold);
        font-style: normal;
        font-weight: 600;
        margin-bottom: 2px;
        color: $blue-main;
        @include media-sm-min {
          @include text(paragraph, large, bold);
          line-height: 25px;
        }
      }
    }
  }
</style>
