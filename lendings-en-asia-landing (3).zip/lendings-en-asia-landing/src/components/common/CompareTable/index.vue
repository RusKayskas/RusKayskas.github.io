<template>
  <div class="compare-table">
    <div class="compare-table__switcher">
      <UiSwitcher
        v-model="priceSwitcher"
        :switcherJson="compareModelJson"
        modelValue="always"
      />
    </div>
    <div class="compare-table__content">
      <div class="compare-table__content-head">
        <div class="compare-table__content-head-block">
          <span>Hide matches</span>
          <UiRadioToggle @changeRadioValue="changeRadioValue" />
        </div>
        <div class="compare-table__content-head-block">
          <p class="title">Basic</p>
          <p class="details">
            from <strong>&#36;{{ basicPrice }} </strong>
          </p>
          <p class="time">{{ timeSwitcher }}</p>
        </div>
        <div class="compare-table__content-head-block">
          <p class="title">Optimal</p>
          <p class="details">
            from <strong>&#36;{{ optimalPrice }} </strong>
          </p>
          <p class="time">{{ timeSwitcher }}</p>
        </div>
      </div>
      <div class="compare-table__content-body">
        <UiAccordion :faq="filteredData" />
      </div>
      <div
        class="compare-table__content-head compare-table__content-head--mobile-bottom"
      >
        <div class="compare-table__content-head-block">
          <p class="title">Basic</p>
          <p class="details">
            from <strong>&#36;{{ basicPrice }} </strong>
          </p>
          <p class="time">{{ timeSwitcher }}</p>
        </div>
        <div class="compare-table__content-head-block">
          <p class="title">Optimal</p>
          <p class="details">
            from <strong>&#36;{{ optimalPrice }} </strong>
          </p>
          <p class="time">{{ timeSwitcher }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
  import UiSwitcher from '@/components/UI/UiSwitcher.vue';
  import UiRadioToggle from '@/components/UI/UiRadioToggle.vue';
  import UiAccordion from '@/components/UI/UiAccordion.vue';
  import tariffsJson from './tariffs.json';
  import { compareModelJson } from '@/page/asia/data.json';
  import { ref, computed } from 'vue';
  const isActive = ref(false);
  const filteredData = ref(tariffsJson.tabs);
  const priceSwitcher = ref('always');
  const basicPrice = computed(() => {
    return priceSwitcher.value === 'always' ? 450 : 200;
  });
  const optimalPrice = computed(() => {
    return priceSwitcher.value === 'always' ? 650 : 300;
  });
  const timeSwitcher = computed(() => {
    return priceSwitcher.value === 'always' ? 'monthly' : 'monthly package';
  });
  const getVisibleColumns = () => {
    return filteredData.value
      .map((tab) => {
        const columns = tab.columns.filter((column) => !column.hide);
        return { ...tab, columns };
      })
      .filter((tab) => tab.columns.length > 0); // Убираем объекты с пустыми colums
  };
  const changeRadioValue = (event) => {
    isActive.value = event;
    filteredData.value = isActive.value
      ? getVisibleColumns()
      : tariffsJson.tabs;
  };
</script>

<style lang="scss">
  .compare-table {
    &__switcher {
      display: flex;
      justify-content: center;
      .ui-switcher {
        max-width: 330px;
      }
    }
    &__content {
      margin-top: 20px;
      @include media-sm-min {
        margin-top: 30px;
      }
      &-head {
        grid-template-columns: 1.5fr 1fr 1fr;
        background: $blue-dark;
        display: grid;
        overflow: hidden;
        border-radius: 10px 10px 0 0;
        position: sticky;
        color: $white;
        top: 35px;
        z-index: 50;
        @include media-sm-min {
          grid-template-columns: repeat(3, 1fr);
        }
        &--mobile-bottom {
          margin-top: 45px;
          position: fixed;
          bottom: 0;
          top: auto;
          border-radius: 0;
          width: 100%;
          grid-template-columns: 1fr 1fr;
          @include media-sm-min {
            display: none;
          }
          .compare-table__content-head-block {
            align-items: center;
            display: flex;
            flex-direction: column;
            &:first-child {
              align-items: center;
            }
            .details,
            .time {
              display: flex;
              align-items: center;
            }
          }
        }
        &-block {
          display: flex;
          padding: 12px 15px;
          .title {
            font-size: 15px;
            font-style: normal;
            font-weight: 600;
            line-height: 20px;
            @include media-sm-min {
              font-size: 20px;
              margin-bottom: 10px;
            }
          }
          .details {
            font-size: 15px;
            display: none;
            @include media-sm-min {
              display: flex;
              justify-content: center;
              align-items: center;
            }
            strong {
              font-weight: 600;
              font-size: 28px;
              line-height: 35px;
              color: $blue-accent;
              margin-left: 10px;
            }
          }
          .time {
            font-size: 15px;
            line-height: 20px;
            display: none;
            @include media-sm-min {
              display: block;
            }
          }
          @include media-sm-min {
            padding: 20px 17.5px;
          }
          &:first-child {
            align-items: flex-end;
            font-size: 15px;
            span {
              display: none;
              @include media-sm-min {
                display: block;
              }
            }
            .ui-radio-toggle {
              margin-left: 15px;
              display: none;
              @include media-sm-min {
                display: block;
              }
            }
          }
          &:not(:first-child) {
            background: $gradient-compare-table;
            text-align: center;
            flex-direction: column;
          }
        }
      }
      &-body {
        .ui-accordion {
          gap: 0;
          padding-bottom: 60px;
          .ui-accordion__card--is-active {
            padding-bottom: 0;
          }
        }
        .ui-accordion__card {
          border: 1px solid $mono-border;
          border-top: 0;
          border-radius: 0;
          &-content {
            &-block {
              button {
                min-width: 18px;
                margin-left: 5px;
              }
              .column {
                font-size: 13px;
                @include text(paragraph, small, normal);
                @include media-sm-min {
                  @include text(paragraph, normal, normal);
                }
                &:first-child {
                  display: block;
                }
              }
            }
          }
        }
      }
    }
  }
</style>
