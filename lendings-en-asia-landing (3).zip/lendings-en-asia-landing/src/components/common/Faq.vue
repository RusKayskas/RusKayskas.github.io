<template>
  <section id="faq" class="faq section--padding">
    <div class="container faq-wrapper">
      <h2 class="faq__title title title--section title--margin">
        {{ $t(faq.title) }}
      </h2>
      <UiAccordion :faq="filterList(faq.list)" hasBorder />
    </div>
  </section>
</template>

<script setup>
  import UiAccordion from '@/components/UI/UiAccordion.vue';
  import { filterList } from '@/helpers/filterList';
  defineProps({
    faq: {
      type: Object,
      required: true,
    },
  });
</script>

<style lang="scss">
  .faq {
    background: $white;
    @include media-sm-min {
      padding-top: 100px !important;
    }
  }
</style>
