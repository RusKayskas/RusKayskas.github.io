import TheHeader from './TheHeader';
import Banner from './Banner';
import AsiaBanner from './AsiaBanner';
import Business from './Business';
import Tariff from './Tariff';
import Advantages from './Advantages';
import Table from './Table';
import Configurator from './Configurator/';
import Partners from './Partners';
import Experts from './Experts';
import WhyDdos from './WhyDdos';
import Personal from './Personal';
import TwinTunnel from './TwinTunnel';
import Faq from './Faq';
import Reviews from './Reviews';
import Protect from './Protect';
import LastScreen from './LastScreen';
import TheFooter from './TheFooter';

export {
  TheHeader,
  AsiaBanner,
  Banner,
  Business,
  Tariff,
  Advantages,
  Table,
  Configurator,
  Partners,
  Experts,
  WhyDdos,
  Personal,
  TwinTunnel,
  Faq,
  Reviews,
  Protect,
  LastScreen,
  TheFooter,
};
