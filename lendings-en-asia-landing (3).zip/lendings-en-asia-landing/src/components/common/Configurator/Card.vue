<template>
  <div class="configurator__card configurator__block">
    <div class="configurator__card-head">
      <p class="configurator__card-head-title title">Your Plan</p>
      <p class="configurator__card-head-price">&#36;{{ price }}</p>
      <p class="configurator__card-head-time">{{ time }}</p>
    </div>
    <div class="configurator__card-content">
      <UiList
        class="configurator__card-content-list"
        :list="formattedList"
        type="success"
      />
      <UiButton
        @action="orderProduct()"
        id="btn-lp-asia-tarif"
        title="Activate"
        class="configurator__card-content-button"
      />
    </div>
  </div>
</template>

<script setup>
  import UiList from '@/components/UI/UiList';
  import UiButton from '@/components/UI/UiButton';
  import { defineProps, computed } from 'vue';

  const props = defineProps({
    level: {
      type: String,
      default: 'basic',
    },
    model: {
      type: String,
      default: 'onDemand',
    },
    bandWidth: {
      type: Number,
      default: 50,
    },
    price: {
      type: Number,
      default: 350,
    },
  });
  const formattedList = computed(() => {
    return [
      `Protection Level <b>${toUpperCaseLevel.value}</b>`,
      `Protection Model <b>${cardModelName.value}</b>`,
      `Bandwidth <b>${+props.bandWidth} Mbps</b>`,
    ];
  });
  const toUpperCaseLevel = computed(() => {
    return props.level === 'basic' ? 'Basic' : 'Optimal';
  });
  const cardModelName = computed(() => {
    return props.model === 'onDemand' ? 'On-Demand' : 'Always-On';
  });
  const time = computed(() => {
    return props.model === 'onDemand' ? 'monthly package' : 'monthly';
  });
  const cardModelNameForDataLayer = computed(() => {
    return props.model === 'onDemand' ? 'on-demand' : 'always';
  });
  import TariffsDataLayer from '@/helpers/eCommerce/tariffsDataLayer';
  function eCoommece() {
    const dataLayer = new TariffsDataLayer(
      props.bandWidth,
      props.price.toString(),
      cardModelNameForDataLayer.value,
    );
    dataLayer.push();
  }
  import { createdCookieWizard } from '@/mixins/createCookie.js';
  const domain = 'https://my.ddos-guard.net/dashboard';
  const orderProduct = () => {
    createdCookieWizard(
      props.bandWidth,
      props.level,
      time.value,
      cardModelNameForDataLayer.value,
    );
    eCoommece();
    window.open(domain, '_blank');
  };
</script>

<style lang="scss">
  .configurator__card {
    display: flex;
    flex-direction: column;
    align-items: center;
    @include media-sm-min {
      max-width: 312px;
    }
    &-head {
      padding-bottom: 14px;
      border-bottom: 1px solid $mono-border;
      width: 100%;
      &-title {
        margin-bottom: 5px;
        font-weight: 600 !important;
        @include media-sm-min {
          @include text(paragraph, extralarge, bold);
        }
      }
      &-price {
        font-size: 28px;
        font-weight: 600;
        line-height: 40px;
        color: $blue-main;
      }
      &-time {
        font-size: 13px;
        font-weight: 400;
        line-height: 15px;
        color: $mono-lables;
      }
    }
    &-content {
      padding-top: 25px;
      width: 100%;
      @include media-sm-min {
        height: 100%;
        display: flex;
        flex-direction: column;
      }
      &-list {
        .ui-list__item {
          @include text(paragraph, small, normal);
          line-height: 15px;
          @include media-sm-min {
            @include text(paragraph, normal, normal);
          }
        }
        b {
          font-weight: 600;
          margin-left: 4px;
        }
      }
      &-button {
        margin-top: 25px;
        width: 100%;
        @include text(paragraph, normal, normal);
        font-weight: 600;
        height: 35px;
        @include media-sm-min {
          margin-top: auto;
          height: auto;
          font-size: 18px;
          padding: 10px 45px;
        }
      }
    }
  }
</style>
