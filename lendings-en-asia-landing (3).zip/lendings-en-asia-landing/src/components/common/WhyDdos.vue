<template>
  <section
    id="ourAdvantages"
    class="section--padding why-ddos section--padding--small-top"
  >
    <div class="container">
      <div class="why-ddos__top">
        <h2 class="why-ddos__top-title title title--section">
          {{ whyDdos.title }}
        </h2>
        <p class="why-ddos__top-details">{{ whyDdos.details }}</p>
      </div>
      <div class="why-ddos-grid">
        <div
          class="why-ddos__card"
          v-for="(item, index) in whyDdos.cards"
          :key="index"
        >
          <span class="why-ddos__card-number why-ddos__card-number--blue"
            >0{{ index + 1 }}</span
          >
          <p class="why-ddos__card-title">{{ item.title }}</p>
          <p class="why-ddos__card-details" v-if="item.details">
            {{ item.details }}
          </p>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
  defineProps({
    whyDdos: {
      type: Object,
      required: true,
    },
  });
</script>

<style lang="scss">
  .why-ddos {
    @include media-sm-min {
      padding-top: 100px !important;
    }
    &-grid {
      display: grid;
      grid-gap: 60px 30px;
      @include media-xs-min {
        grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
      }
      @include media-sm-min {
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        grid-gap: 100px 30px;
      }
    }
    &__top {
      margin-bottom: 60px;
      @include media-sm-min {
        margin-bottom: 120px;
      }
      &-title {
        text-align: left !important;
        margin-bottom: 0;
        @include media-sm-min {
          line-height: 55px !important;
        }
      }
      &-details {
        margin-top: 10px;
        line-height: 25px;
        @include media-sm-min {
          margin-top: 20px;
        }
      }
    }
    &__card {
      display: flex;
      flex-direction: column;
      &-number {
        font-size: 90px;
        line-height: 0.1;
        color: transparent;
        font-weight: 800;
        -webkit-text-stroke: 1px $blue-main;
        @include media-xs-min {
          font-size: 120px;
        }
        @include media-sm-min {
          font-size: 140px;
        }
        &--blue {
          color: $blue-bg;
          -webkit-text-stroke: 0px $blue-main;
        }
      }
      &-title {
        font-size: 13px;
        font-weight: 600;
        line-height: 20px;
        margin-bottom: 5px;
        @include media-xs-min {
          margin-bottom: 10px;
          font-size: 15px;
          line-height: 25px;
        }
        @include media-sm-min {
          font-size: 140px;
          font-size: 17px;
          max-width: 290px;
        }
      }
      &-details {
        opacity: 0.7;
        font-size: 13px;
        line-height: 20px;
        @include media-sm-min {
          font-size: 15px;
          line-height: 25px;
        }
      }
    }
  }
  .ourAdvantages-wrapper.grid {
    row-gap: 30px;
    padding-top: 15px;
    @include media-xs-min {
      row-gap: 50px;
    }
    @include media-sm-min {
      row-gap: 70px;
      padding-top: 20px;
    }
  }
</style>
