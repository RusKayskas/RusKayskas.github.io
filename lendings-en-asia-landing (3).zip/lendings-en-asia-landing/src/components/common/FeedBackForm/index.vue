<template>
  <form
    @submit.prevent="submitForm"
    :id="feedBackForm.id"
    :name="feedBackForm.name"
    class="feedback-form"
    type="bot"
  >
    <div class="feedback-form__body feedback-form__block">
      <!-- name input-->
      <div class="feedback-form__inputs-group">
        <UiInput
          :label="$t(feedBackForm.inputs.nameInput.labelName)"
          required
          :details="$t(feedBackForm.required.details)"
          v-model.trim="state.name"
          :id="feedBackForm.inputs.nameInput.id"
          :type="feedBackForm.inputs.nameInput.type"
          :name="feedBackForm.inputs.nameInput.name"
          :class="isInputError(v$.name.$error)"
          @keypress="isLetter($event)"
          @input="v$.name.$validate()"
        />
        <!-- phone input-->
        <UiInput
          v-mask="'+## ### ###-####'"
          :label="$t(feedBackForm.inputs.phoneInput.labelName)"
          v-model="state.phone"
          :id="feedBackForm.inputs.phoneInput.id"
          :type="feedBackForm.inputs.phoneInput.type"
          :name="feedBackForm.inputs.phoneInput.name"
          placeholder="+55 (___) ___-__-__"
        />
      </div>
      <!-- email input-->
      <UiInput
        :label="feedBackForm.inputs.emailInput.labelName"
        required
        :details="$t(feedBackForm.required.details)"
        v-model.trim="state.email"
        :id="emailId"
        :type="feedBackForm.inputs.emailInput.type"
        :name="feedBackForm.inputs.emailInput.name"
        :class="isInputError(v$.email.$error)"
        @input="v$.email.$validate()"
      />

      <!-- textarea -->
      <UiInput
        tag="textarea"
        required
        v-model.trim="state.comment"
        :label="$t(feedBackForm.inputs.textarea.labelName)"
        :id="commentId"
        :name="feedBackForm.inputs.textarea.name"
        :details="$t(feedBackForm.required.details)"
        :class="['ui-field--textarea', isInputError(v$.comment.$error)]"
        @input="v$.comment.$validate()"
      />
    </div>

    <div class="feedback-form__footer feedback-form__block">
      <div class="feedback-form__footer-capcha">
        <Recapcha v-model="recaptcha" @verify="checkRecapcha" />
      </div>
      <UiCheckbox
        v-model="state.checkbox"
        :value="state.checkbox"
        @change="v$.checkbox.$touch()"
        :class="[
          'feedback-form__footer-checkbox',
          isInputError(v$.checkbox.$error),
        ]"
        :label="$t(feedBackForm.inputs.checkbox.label)"
      />
      <UiButton
        :disabled="isDisabled"
        button="submit"
        class="feedback-form__footer-button ui-button--green"
        :title="buttonTitle"
        :id="buttonId"
      />
    </div>
  </form>
</template>

<script setup>
  import { required, email } from '@vuelidate/validators';
  import { useVuelidate } from '@vuelidate/core';
  import { reactive, computed, ref } from 'vue';
  import { useModalSlot } from 'vue-final-modal';
  import { useI18n } from 'vue-i18n';
  import AxiosApi from '@/services/axios';
  //компоненты
  import { UiButton, UiInput, UiCheckbox } from '@/components/UI';
  import Recapcha from './Recapcha.vue';
  import ModalReport from './ModalReport.vue';
  import FeedbackForm from '@/components/common/FeedBackForm/index.vue';
  //dataJson
  import { feedBackForm, modal, modalReport } from '@/page/asia/data.json';
  defineProps({
    buttonId: {
      type: String,
      default: 'buttonId',
    },
    emailId: {
      type: String,
      default: 'emailId',
    },
    commentId: {
      type: String,
      default: 'commentId',
    },
    buttonTitle: {
      type: String,
      default: 'Send',
    },
  });

  const isDisabled = ref(true);
  const recaptcha = ref(null);
  const { t } = useI18n();
  //валидация
  const state = reactive({
    name: '',
    email: '',
    phone: '',
    comment: '',
    checkbox: false,
  });
  const rules = computed(() => {
    return {
      name: { required },
      comment: { required },
      email: { required, email },
      checkbox: { required, checked: (value) => value === true },
    };
  });
  const v$ = useVuelidate(rules, state);
  //только буквы
  const isLetter = (e) => {
    let char = String.fromCharCode(e.keyCode);
    if (/^([а-яёА-ЯЁ]+|[a-zA-Z]+)$/.test(char)) return true;
    else e.preventDefault();
  };
  import { createModal } from '@/services/createModal';
  //модалки
  const modalReportSuccess = createModal(ModalReport);

  const modalReportError = createModal(ModalReport);

  modalReportError.patchOptions({
    slots: {
      default: useModalSlot({
        attrs: {
          title: t(modalReport.error.title),
          details: t(modalReport.error.details),
          imgSrc: modalReport.error.imgSrc,
          imgAlt: t(modalReport.error.imgAlt),
          btnTitle: t(modalReport.error.btnTitle),
          onConfirm() {
            feedBackFormModal.open();
            modalReportError.close();
          },
        },
      }),
    },
  });
  // модалка для вызова формы
  const feedBackFormModal = createModal(
    FeedbackForm,
    t(modal.title),
    t(modal.details),
  );
  feedBackFormModal.patchOptions({
    slots: {
      default: useModalSlot({
        attrs: {
          onConfirm() {
            feedBackFormModal.close();
          },
        },
      }),
    },
  });
  //получание значения recapcha , обработка ошибок ,отправка формы
  function checkRecapcha(response) {
    recaptcha.value = response;
  }
  function isInputError(value) {
    disableButtonCheck();
    return value ? 'ui-field--is-invalid' : 'ui-field--is-valid';
  }

  function disableButtonCheck() {
    isDisabled.value =
      !v$.value.$invalid && recaptcha.value !== null ? false : true;
  }
  function submitForm() {
    v$.value.$validate();
    if (!v$.value.$error && recaptcha.value) sendForm();
  }

  const $emit = defineEmits(['confirm']);
  const type = ref('webprotection-medium');

  async function sendForm() {
    const form = document.forms[feedBackForm.id];
    const formData = new FormData(form);
    formData.set('reCaptcha', formData.get('g-recaptcha-response'));
    formData.set('type', type.value);
    let $axios = new AxiosApi();
    await $axios.axios
      .post('https://ddos-guard.net/ajax/feedback-landings', formData, {
        headers: {
          'X-Requested-With': 'XMLHttpRequest',
        },
      })
      .then(() => {
        $emit('confirm');
        setTimeout(() => {
          modalReportSuccess.open();
        }, 0);
        recaptcha.value = '';
      })
      .catch(() => {
        $emit('confirm');
        setTimeout(() => {
          modalReportError.open();
        }, 0);
        recaptcha.value = '';
      });
  }
</script>

<style lang="scss">
  .feedback-form {
    display: flex;
    background-color: $white;
    color: $mono-main;
    flex-direction: column;
    &__block {
      padding: 20px 15px 0px 15px;
      @include media-xs-min {
        padding: 30px 30px 25px 30px;
      }
    }
    &__inputs-group {
      display: flex;
      flex-direction: column;
      @include media-xs-min {
        flex-direction: row;
        justify-content: space-between;
      }
      .ui-field {
        max-width: 100%;
        @include media-xs-min {
          max-width: 47%;
        }
      }
    }
    &__body {
      &-capcha {
        margin: 25px 0;
        height: 70px;
      }
      &-chekbox {
        margin-bottom: 25px;
      }
    }
    &__footer {
      padding: 0 15px 40px 15px;
      margin-top: 10px;
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      @include media-xs-min {
        margin-top: 0;
        padding: 0 30px 30px 30px;
      }
      &-checkbox {
        margin-top: 25px;
      }
      &-button {
        margin-top: 25px;
        @include media-xs-min {
          width: fit-content;
        }
      }
    }
  }
</style>
