<template>
  <div
    class="ui-radio-toggle"
    :class="{ 'ui-radio-toggle--is-active': isActive }"
    @click="toggleRadio"
  >
    <div class="ui-radio-toggle__slider"></div>
  </div>
</template>

<script setup>
  import { ref, defineEmits } from 'vue';
  const isActive = ref(false);
  const emit = defineEmits(['changeRadioValue']);
  const toggleRadio = () => {
    isActive.value = !isActive.value;
    emit('changeRadioValue', isActive.value);
  };
</script>

<style lang="scss">
  .ui-radio-toggle {
    width: 35px;
    height: 20px;
    background-color: $mono-lables;
    border-radius: 20px;
    padding: 2px;
    display: flex;
    align-items: center;
    cursor: pointer;
    transition: background-color 0.3s;
    &__slider {
      width: 16px;
      height: 16px;
      background-color: $white;
      border-radius: 50%;
      transition: transform 0.3s;
    }
    &--is-active {
      background-color: $blue-hover;
      .ui-radio-toggle__slider {
        transform: translateX(15px);
      }
    }
  }
</style>
