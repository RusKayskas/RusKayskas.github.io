<template>
  <div class="ui-switcher">
    <div
      class="ui-switcher__block"
      v-for="(item, index) in switcherJson"
      :key="index"
    >
      <input
        class="ui-switcher__input"
        type="radio"
        :name="switchValue"
        @change="({ target }) => (switchValue = target.value)"
        :value="item.valueModel"
        v-model="switchValue"
        :id="item.valueModel"
        :checked="switchValue === item.valueModel"
      />
      <label class="ui-switcher__label" :for="item.valueModel">
        {{ item.model }}
        <UiTooltip v-if="item.tooltip" :content="item.tooltip" />
      </label>
    </div>
  </div>
</template>

<script setup>
  import { ref, defineEmits, defineProps, watchEffect } from 'vue';
  import { UiTooltip } from '@/components/UI';

  const props = defineProps({
    switcherJson: {
      type: Array, // Изменено на массив
      required: true,
    },
    modelValue: {
      type: String,
      default: 'origin',
    },
  });

  const emit = defineEmits(['update:modelValue']);
  const switchValue = ref(props.modelValue);

  watchEffect(() => {
    emit('update:modelValue', switchValue.value);
  });
</script>

<style lang="scss">
  .ui-switcher {
    $bg-padding: 5px;
    $button-width: 138px;
    width: 100%;
    display: flex;
    justify-content: space-between;
    position: relative;
    padding: $bg-padding;
    border-radius: 5px;
    background-color: $blue-bg;
    $animation-time: 0.3s;
    &__block {
      width: 100%;
      &:not(:last-child) {
        margin-right: 4px;
      }
    }
    &__input {
      position: absolute;
      opacity: 0;
      &:checked + label {
        color: $mono-main;
        text-decoration: none;
        background-color: $white;
      }
    }
    &__label {
      position: relative;
      font-size: 13px;
      z-index: 1;
      display: inline-block;
      width: 100%;
      height: 25px;
      line-height: 25px;
      cursor: pointer;
      color: $gray-blue;
      transition-delay: 0.1s;
      border-radius: 3px;
      transition: color $animation-time ease;
      text-align: center;
      @include media-sm-min {
        height: 35px;
        line-height: 35px;
      }
    }
  }
</style>
