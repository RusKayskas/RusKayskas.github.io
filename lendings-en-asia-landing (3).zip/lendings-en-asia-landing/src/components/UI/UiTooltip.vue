<template>
  <tippy
    interactive
    tag="button"
    content-tag="div"
    content-class="content-wrapper"
  >
    <template #default
      ><img
        svg-inline
        :src="require(`@/assets/images/${icon}`)"
        alt="подробнее"
    /></template>
    <template #content>
      <div class="tippy-content" v-html="content"></div>
    </template>
  </tippy>
</template>

<script setup>
  import { Tippy } from 'vue-tippy';

  defineProps({
    content: {
      type: String,
      default: '',
    },
    icon: {
      type: String,
      default: 'asia/icons/question.svg',
    },
  });
</script>

<style lang="scss">
  @import 'tippy.js/dist/tippy.css';

  .tippy-box {
    text-align: left;
    font-size: 13px;
    position: relative;
    z-index: 3;
    line-height: 20px;
    min-width: 250px;
    font-weight: 400;
    .tippy-content {
      @include media-sm-min {
        min-width: 300px;
      }
      a {
        color: $blue-main;
        @media (hover: hover) {
          transition: all 0.4s linear;
          &:hover {
            color: $blue-hover;
          }
        }
      }
    }
  }
</style>
