<template>
  <div class="ui-radio-tabs">
    <div class="ui-radio-tabs-wrapper">
      <div
        v-for="(item, index) in radioData"
        :key="index"
        @change="emit('update:modelValue', radioValue)"
        :class="[
          'ui-radio-tabs__card',
          { 'ui-radio-tabs__card--is-active': radioValue === item.value },
        ]"
      >
        <div
          :class="[
            'ui-radio-tabs__card-additional',
            item.color ? `ui-radio-tabs__card-additional--${item.color}` : '',
          ]"
        >
          {{ item.additional }}
        </div>
        <div class="ui-radio-tabs__card-head">
          <label class="ui-radio-tabs__card-head-label">
            <input
              class="ui-radio-tabs__card-head-input"
              type="radio"
              :name="radioValue"
              :value="item.value"
              @input="onRadioChange"
              :checked="radioValue === item.value"
            />
            <span>{{ item.level }}</span>
          </label>
        </div>
        <div
          v-show="radioValue === item.value"
          class="ui-radio-tabs__card-content"
        >
          <p
            v-for="(list, index) in item.list"
            :key="index"
            class="ui-radio-tabs__card-content-details"
            v-html="list"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
  import { ref, defineEmits } from 'vue';

  const props = defineProps({
    modelValue: {
      type: String,
      default: 'basic',
    },
    radioData: {
      type: Object,
      required: true,
    },
  });

  const emit = defineEmits(['update:modelValue']);
  const radioValue = ref(props.modelValue);

  const onRadioChange = (event) => {
    radioValue.value = event.target.value;
  };
</script>

<style lang="scss">
  .ui-radio-tabs {
    &__card {
      position: relative;
      border-radius: 5px;
      border: 1px solid $blue-bg;
      &:not(:last-child) {
        margin-bottom: 10px;
      }
      &--is-active {
        border-color: $blue-main;
        .ui-radio-tabs__card-head-label {
          background-color: $white;
          padding-bottom: 5px;
        }
        .ui-radio-tabs__card-head-input {
          border: 5px solid $blue-main;
        }
      }
      &-additional {
        position: absolute;
        right: -1px;
        top: -1px;
        border-radius: 0px 5px;
        background: $blue-main;
        @include text(paragraph, smallrange, bold);
        font-weight: 600;
        line-height: 20px;
        padding: 1px 10px;
        color: $white;
        &--green {
          background: $green-main;
        }
      }
      &-head {
        &-label {
          cursor: pointer;
          width: 100%;
          height: 100%;
          display: block;
          text-align: left;
          border-radius: 5px;
          padding: 15px;
          background: $blue-bg;
          display: flex;
          align-items: center;
        }
        &-input {
          margin-right: 10px;
          width: 15px;
          height: 15px;
          display: block !important;
          cursor: pointer;
          display: block !important;
          border-radius: 50%;
          border: 1px solid $mono-lables;
          margin-right: 10px !important;
          -webkit-appearance: none !important;
          -moz-appearance: none !important;
          appearance: none !important;
          outline: none;
          transition: all 0.1s linear;
        }
      }
      &-content {
        text-align: left;
        padding: 10px 15px 15px 40px;
        @include text(paragraph, smaller, normal);
        @include media-sm-min {
          @include text(paragraph, small, normal);
          line-height: 15px;
        }
        &-details {
          color: $mono-buttons-tabs;
          &:not(:last-child) {
            margin-bottom: 5px;
          }
        }
      }
    }
  }
</style>
