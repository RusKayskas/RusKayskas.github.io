<template>
  <vue-final-modal
    v-slot="{}"
    v-bind="$attrs"
    class="modal-container"
    content-class="modal-content"
    overlay-transition="vfm-fade"
    content-transition="vfm-fade"
    @update:model-value="(value) => $emit('update:modelValue', value)"
  >
    <div class="modal-wrapper modal">
      <div class="modal__header">
        <div class="modal__header-text" v-if="modalTitle">
          <span class="modal__header-text-title title">{{ modalTitle }}</span>
          <p class="modal__header-text-details" v-if="modalDetails">
            {{ modalDetails }}
          </p>
        </div>
        <div class="modal__header-close-wrapper">
          <button
            @click="$emit('update:modelValue', false)"
            type="button"
            class="modal__header-close"
          >
            <img svg-inline src="@/assets/images/modal/close.svg" alt="Сlose" />
          </button>
        </div>
      </div>
      <div class="modal__content">
        <slot />
      </div>
    </div>
  </vue-final-modal>
</template>

<script setup>
  import { VueFinalModal } from 'vue-final-modal';
  import { defineEmits, defineProps } from 'vue';
  defineEmits(['update:modelValue']);
  defineProps({
    modalTitle: {
      type: String,
      default: '',
    },
    modalDetails: {
      type: String,
      default: '',
    },
    fullScreen: {
      type: String,
      default: '',
    },
  });
</script>

<style lang="scss">
  //стили для обертки модалки
  .modal-container {
    display: flex;
    justify-content: center;
    align-items: center;
    &--fullScreen {
      .modal-content {
        width: 100%;
        max-width: 100%;
        border-radius: 0;
        margin: 0;
        height: 100%;
        overflow: auto;
        padding-bottom: 61px;
        .modal {
          max-width: 1110px;
          position: unset;
          margin: 0 auto;
          &__header {
            &-text {
              border-bottom: none;
              padding-top: 35px;
              text-align: center;
              align-items: center;
              @include media-xs-min {
                padding-top: 70px;
              }
              &-title {
                @include text(h2, normal, bold);
              }
            }
            &-close-wrapper {
              position: absolute;
              top: 0;
              background: #fff;
              width: 100%;
              z-index: 2;
              left: 0;
              display: flex;
              justify-content: flex-end;
            }
            &-close {
              position: relative;
              width: 35px;
              height: 35px;
              right: 0;
              top: 0;
              outline: none;
              @include media-sm-min {
                width: 50px;
                height: 50px;
              }
              &:focus {
                outline: none;
              }
              &:active {
                overflow: none;
              }
            }
          }
        }
      }
    }
  }
  .modal-content {
    position: relative;
    display: flex;
    flex-direction: column;
    background: $white;
    overflow: hidden;
    border-radius: 10px;
    @include media-xs-min {
      flex-direction: row;
      flex-wrap: wrap;
      max-width: 500px;
      border-radius: 10px;
      margin: 0 1rem;
      height: fit-content;
    }
  }
  .modal {
    width: 100%;
    position: relative;
    overflow: auto;
    &__header {
      &-text {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        justify-content: space-between;
        padding: 25px 15px;
        border-bottom: 1px solid $modal-border;
        @include media-xs-min {
          padding: 25px 30px;
        }
        &-title {
          font-size: 20px;
          line-height: 30px;
          position: relative;
          z-index: 3;
        }
        &-details {
          max-width: 375px;
          font-size: 15px;
          line-height: 25px;
          color: $mono-buttons-tabs;
        }
      }
      &-close-wrapper {
        position: absolute;
        right: 15px;
        top: 30px;
        @include media-mb-min {
          right: 30px;
        }
      }
      &-close {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 20px;
        height: 20px;
      }
    }
  }
</style>
