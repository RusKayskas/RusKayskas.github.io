<template>
  <section :id="id" class="ui-section s-gradient">
    <div class="container ui-section-wrapper">
      <div class="ui-section__text" v-if="hasTitle">
        <slot name="text" />
      </div>
      <div class="ui-section__content">
        <slot name="content" />
      </div>
    </div>
  </section>
</template>
<script setup>
  defineProps({
    id: {
      type: String,
      required: false,
    },
    hasTitle: {
      type: Boolean,
      default: false,
    },
  });
</script>

<style lang="scss">
  .ui-section {
    padding: 60px 0;
    @include media-xs-min {
      padding: 80px 0;
    }
    &--no-padding {
      padding: 60px 0 0 0;
      @include media-xs-min {
        padding: 80px 0 0 0;
      }
      @include media-sm-min {
        padding: 0;
      }
    }
    &.s-gradient {
      &::before {
        display: block;
        width: 787px;
        height: 690px;
        filter: blur(100px);
        border-radius: 787px;
        top: 15%;
        @include media-sm-min {
          width: 815px;
          height: 716px;
          border-radius: 935px;
          filter: blur(200px);
        }
      }
    }
    &-wrapper {
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      gap: 40px 15px;
      @include media-xs-min {
        gap: 50px 15px;
      }
      @include media-sm-min {
        flex-direction: row;
        justify-content: space-between;
        flex-wrap: wrap;
      }
    }
    &__text {
      text-align: center;
      display: flex;
      flex-direction: column;
      align-items: center;
      @include media-sm-min {
        padding: 0;
        text-align: left;
        max-width: 540px;
        align-items: flex-start;
      }
      &-title {
        text-align: center;
        margin-bottom: 10px;
        @include media-sm-min {
          text-align: left;
        }
      }
      &-details {
        @include text(paragraph, normal, bold);
        font-weight: 600;
        line-height: 25px;
        margin-bottom: 40px;
        @include media-xs-min {
          margin-bottom: 50px;
        }
        @include media-sm-min {
          font-size: 17px;
          max-width: 100%;
        }
      }
    }
    &__content {
      width: 100%;
      text-align: center;
      flex: 1;
      min-width: 100%;
      @include media-sm-min {
        text-align: right;
        min-width: 360px;
      }
    }
  }
</style>
