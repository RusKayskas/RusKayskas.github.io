<template>
  <div class="ui-range">
    <div class="ui-range-wrapper">
      <input
        ref="inputInner"
        :value="inputInnerValue"
        type="text"
        @input="onNumberInput"
        @keypress="onKeyPress"
        @focus="inputInnerFocus"
        @blur="blurInputValue"
        class="ui-range__input"
      />
      <UiSliderRange
        ref="slider"
        v-model="selectedValue"
        :min="0"
        :lazy="false"
        :tooltips="false"
        :max="sliderRangeMax"
        @input="emit('rangeUp', rangeValue)"
        class="ui-range__slider"
      />
    </div>
    <div class="ui-range__bottom">
      <span class="ui-range__bottom-number">{{ rangeMin }}</span>
      <span class="ui-range__bottom-number">{{ rangeMax }}</span>
    </div>
  </div>
</template>

<script setup>
  import UiSliderRange from './UiSliderRange.vue';
  import {
    ref,
    computed,
    onMounted,
    watchEffect,
    defineEmits,
    watch,
  } from 'vue';
  const onKeyPress = (event) => {
    const isValidInput = /^[0-9]+$/.test(event.key);
    if (!isValidInput) event.preventDefault();
  };
  const props = defineProps({
    values: {
      type: Array,
      default: () => [50, 100, 200, 300, 400, 500, 600, 700, 800, 1000],
    },
  });
  const rangeMin = computed(() => {
    return props.values[0];
  });
  const rangeMax = computed(() => {
    return props.values.at(-1);
  });
  const selectedValue = ref(0);
  const slider = ref();
  onMounted(() => {
    selectedValue.value = 0;
  });
  const selectedOutput = computed(() => {
    return props.values[selectedValue.value];
  });

  const inputInnerValue = computed(() => {
    return selectedOutput.value + ' ' + 'Mbps';
  });
  const sliderRangeMax = computed(() => {
    return props.values.length - 1;
  });
  const inputInnerFocus = () => {
    inputInner.value.value = '';
  };
  let inputTimer; // Переменная для хранения таймера

  // функция блюр с возвратом значения
  const inputInner = ref();
  const blurInputValue = () => {
    inputInner.value.value = selectedOutput.value.toString() + ' ' + 'Mbps';
  };
  const onNumberInput = (event) => {
    let inputValue = event.target.value;

    // Убираем предыдущий таймер, если он был установлен
    clearTimeout(inputTimer);
    // Устанавливаем новый таймер на окончание ввода через 500 мс
    inputTimer = setTimeout(() => {
      // Проверяем, введено ли три символа или более
      if (inputValue.length >= 2) {
        // Парсим введенное значение
        const parsedValue = parseFloat(inputValue);
        // Если значение успешно распарсено, обновляем selectedValue
        if (!isNaN(parsedValue)) {
          const closestValue = findClosestValue(parsedValue);
          selectedValue.value = props.values.indexOf(closestValue);
        }
        inputInner.value.blur();
      }
    }, 600);
  };

  // Функция для поиска ближайшего значения в массиве
  const findClosestValue = (targetValue) => {
    return props.values.reduce((prev, curr) => {
      return Math.abs(curr - targetValue) < Math.abs(prev - targetValue)
        ? curr
        : prev;
    });
  };
  const emit = defineEmits(['rangeUp']);
  watchEffect(() => {
    emit('rangeUp', selectedOutput.value);
  });

  const rangeValue = ref(selectedOutput);
  watch(
    () => props.values,
    (newValues) => {
      if (newValues.length > 0) {
        selectedValue.value = 0;
        emit('rangeUp', rangeValue.value);
      }
    },
  );
</script>
<style lang="scss">
  .ui-range {
    --trackHeight: 5px;
    --thumbRadius: 15px;
    &-wrapper {
      position: relative;
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-orient: vertical;
      -webkit-box-direction: normal;
      -ms-flex-direction: column;
      flex-direction: column;
      position: relative;
      margin-bottom: 10px;
    }
    &__input {
      padding: 3px 10px 5px 15px;
      border-radius: 5px;
      border: 1px solid $mono-border;
      @include text(paragraph, smallrange, normal);
      outline: none;
      height: 35px;
      @include media-sm-min {
        @include text(paragraph, normal, normal);
        line-height: 20px;
        height: 45px;
        padding: 7px 15px 11px 15px;
      }
      &:focus {
        border-color: $blue-focus;
      }
      &:active {
        border-color: $blue-focus;
      }
    }
    &__slider {
      position: absolute;
      bottom: 3px;
      transform: translateY(50%);
      width: 100%;
      border-radius: 999px;
      &-numbers {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-pack: justify;
        -ms-flex-pack: justify;
        justify-content: space-between;
        margin-top: 5px;
        font-size: 11px;
      }
    }
    &__bottom {
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      width: 100%;
      -webkit-box-pack: justify;
      -ms-flex-pack: justify;
      justify-content: space-between;
      -webkit-box-align: start;
      -ms-flex-align: start;
      align-items: flex-start;
      &-number {
        color: $mono-buttons-tabs;
        @include text(paragraph, smaller, normal);
      }
    }
  }
</style>
