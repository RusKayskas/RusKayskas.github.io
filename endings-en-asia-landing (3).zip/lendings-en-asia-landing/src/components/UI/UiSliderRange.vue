<template>
  <Slider class="slider-blue" :min="min" :max="max" />
</template>

<script setup>
  // import '@vueform/slider/themes/default.css';
  import Slider from '@vueform/slider';
  defineProps({
    min: {
      type: Number,
      default: 0,
    },
    max: {
      type: Number,
      default: 10,
    },
  });
</script>

<style lang="scss">
  .slider-blue {
    --slider-bg: #e7f0ff;
    --slider-connect-bg: #0077ff;
    --slider-handle-ring-color: #ffffff;
    --slider-handle-bg: #0077ff;
    --slider-handle-border: 2px;
    --slider-handle-shadow: 2px 2px 2px rgba(255, 255, 255, 1);
    --slider-handle-shadow-active: 0 4px 20px rgba(0, 0, 0, 0.25);
    --slider-handle-width: 13px;
    --slider-handle-height: 13px;
    --slider-height: 5px;
    --slider-handle-ring-width: 2px;
  }
</style>
