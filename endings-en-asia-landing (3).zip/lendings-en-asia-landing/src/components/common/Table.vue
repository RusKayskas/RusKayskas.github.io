<template>
  <section id="protecting" class="s-gradient table section--padding">
    <div class="container">
      <div class="text">
        <h2 class="title title--section title--margin">Protecting Against</h2>
      </div>

      <UiSlider isDisabled media="slider-nav__media" color="white">
        <div
          class="table__block keen-slider__slide"
          v-for="(slide, index) in table.cards"
          :key="index"
        >
          <div class="table__block-title title">
            {{ slide.title }}
          </div>
          <div class="table__block-content">
            <ul>
              <li v-for="(item, index) in slide.list" :key="index">
                {{ item }}
              </li>
            </ul>
          </div>
        </div>
      </UiSlider>
      <p class="table__bottom-details">
        and a wide range of other DDoS attack types
      </p>
    </div>
  </section>
</template>

<script setup>
  defineProps({
    table: {
      type: Object,
      required: true,
    },
  });
  import { UiSlider } from '@/components/UI';
</script>

<style lang="scss">
  //desctop
  .slider-nav__media {
    @include media-xs-min {
      display: none;
    }
  }
  .table {
    @include media-sm-min {
      padding: 100px 0 !important;
    }
    &.s-gradient {
      &::before {
        width: 515.948px;
        height: 343.445px;
        right: -177.474px;
        bottom: -10.907px;
        border-radius: 515.948px;
        background: linear-gradient(
          301deg,
          #22377c 25.21%,
          rgba(233, 100, 255, 0.55) 33.8%,
          rgba(156, 102, 246, 0.69) 75.9%
        );
        opacity: 0.6;
        filter: blur(50px);
        @include media-xs-min {
          width: 935px;
          height: 822px;
          bottom: -473px;
          border-radius: 935px;
          opacity: 0.7;
          background: linear-gradient(
            298deg,
            rgba(233, 100, 255, 0.63) 32.11%,
            #006be5 80.9%
          );
          filter: blur(200px);
        }
      }
    }
    .ui-slider-wrapper {
      padding: 0;
      margin: 0;
    }
    &__block {
      width: 33%;
      display: table-cell;
      text-align: center;
      @include media-xs-min {
        &:not(:last-child) {
          border-right: 1px solid rgba(255, 255, 255, 0.3);
        }
      }
      &-title {
        padding: 15px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.3);
        font-weight: 600 !important;
        @include text(paragraph, small, normal);
        position: relative;
        @include media-xs-min {
          height: 110px;
          display: table-cell;
          vertical-align: middle;
          width: 33%;
        }
        @include media-sm-min {
          height: 80px;
          @include text(paragraph, large, normal);
        }
      }
      &-content {
        li {
          padding: 15px;
          font-size: 15px;
          font-style: normal;
          @include text(paragraph, small, normal);
          display: flex;
          justify-content: center;
          align-items: center;
          @include media-xs-min {
            @include text(paragraph, normal, normal);
            line-height: 25px;
          }
          &:nth-child(even) {
            background: rgba(255, 255, 255, 0.1);
          }
          &:nth-child(2) {
            @include media-xs-min {
              height: 80px;
            }
          }
          &:nth-child(3) {
            @include media-xs-min {
              height: 80px;
            }
          }
          &:nth-child(4) {
            @include media-xs-min {
              height: 80px;
            }
          }
        }
      }
    }
    &__bottom-details {
      text-align: center;
      @include text(paragraph, small, normal);
      margin-top: 40px;
      @include media-sm-min {
        @include text(paragraph, large, normal);
        margin-top: 60px;
      }
    }
  }
</style>
