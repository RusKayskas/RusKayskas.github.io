<template>
  <div class="configurator__technical configurator__block">
    <div class="configurator__technical-head">
      <p class="configurator__technical-head-title title">Technical Details</p>
    </div>
    <div class="configurator__technical-body">
      <p class="configurator__technical-title">
        <span>Protection Level</span>
        <UiTooltip
          content="<span>Learn more about your protection level <a target='_blank' href='https://ddos-guard.net/en/technologies/protection-levels'>here</a></span>"
        />
      </p>
      <UiRadioTabs
        :radioData="dataJson.protectionLevel"
        v-model="ProtectionLevel"
        @change="$emit('protectionLevel', ProtectionLevel)"
      />
    </div>
    <div class="configurator__technical-footer">
      <div class="configurator__technical-footer-block">
        <p class="configurator__technical-title">
          <span>Protection Model</span>
        </p>
        <UiSwitcher
          :switcherJson="protectionModelJson"
          modelValue="origin"
          v-model="ProtectionModel"
          @change="$emit('ProtectionModel', ProtectionModel)"
        />
      </div>
      <div class="configurator__technical-footer-block">
        <p class="configurator__technical-title">
          <span>Bandwidth</span>
          <UiTooltip
            content="The legitimate traffic bandwidth that is available to you"
          />
        </p>
        <UiRange :values="currentRange" @rangeUp="rangeUp" />
      </div>
    </div>
  </div>
</template>

<script setup>
  import UiRadioTabs from '@/components/UI/UiRadioTabs.vue';
  import UiRange from '@/components/UI/UiRange.vue';
  import UiSwitcher from '@/components/UI/UiSwitcher';
  import UiTooltip from '@/components/UI/UiTooltip';
  import dataJson from '@/page/asia/data.json';
  import { ref, watchEffect, defineEmits } from 'vue';
  import { protectionModelJson } from '@/page/asia/data.json';
  const ProtectionModel = ref('origin');
  const ProtectionLevel = ref('basic');
  const $emit = defineEmits([
    'rangeToIndex',
    'protectionLevel',
    'ProtectionModel',
  ]);
  // значение range
  import tariffJson from './tariffs.json';
  //Json получение цены и переключение range
  const originStep = Object.keys(tariffJson.origin).map((str) => +str);
  const onDemandStep = Object.keys(tariffJson.onDemand).map((str) => +str);
  const currentRange = ref(originStep);
  watchEffect(() => {
    currentRange.value =
      ProtectionModel.value === 'origin' ? originStep : onDemandStep;
  });
  const rangeValue = ref();
  const rangeUp = (event) => {
    rangeValue.value = event;
    $emit('rangeToIndex', rangeValue.value);
  };
</script>

<style lang="scss"></style>
