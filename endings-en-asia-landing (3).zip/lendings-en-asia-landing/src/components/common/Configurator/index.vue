<template>
  <section id="configurator" class="configurator section--padding">
    <div class="container">
      <h2 class="configurator__title title title--section title--margin">
        Configure Your Plan
      </h2>
      <div class="configurator-wrapper">
        <Technical
          @protectionLevel="protectionLevel"
          @ProtectionModel="protectionModel"
          @rangeToIndex="rangeToIndex"
        />
        <Card
          :level="level"
          :model="model"
          :bandWidth="newRange"
          :price="currentPrice"
        />
      </div>
      <div class="configurator__bottom">
        <UiButton
          @action="compateTableModal.open()"
          class="ui-button--border configurator__bottom-ui-button"
          title="Compare Protection Levels"
          icon="asia/icons/angle-right.svg"
        />
      </div>
    </div>
  </section>
</template>
<script setup>
  import Technical from './Technical.vue';
  import Card from './Card.vue';
  import UiButton from '@/components/UI/UiButton';
  import { ref, watchEffect } from 'vue';
  import jsonTariff from './tariffs.json';
  const level = ref('basic');
  const model = ref('origin');
  const protectionLevel = (event) => {
    level.value = event;
  };
  const protectionModel = (event) => {
    model.value = event;
  };
  const jsonData = ref(jsonTariff);
  const currentPrice = ref(null);
  const currency = ref('USD');
  //new range
  const newRange = ref();
  const rangeToIndex = (event) => {
    newRange.value = event;
  };
  watchEffect(() => {
    if (
      jsonData.value &&
      jsonData.value[model.value] &&
      jsonData.value[model.value][newRange.value] &&
      jsonData.value[model.value][newRange.value][level.value]
    ) {
      currentPrice.value =
        jsonData.value[model.value][newRange.value][level.value][
          currency.value
        ].asia.price;
    }
  });

  //modal
  import CompareTable from '@/components/common/CompareTable/index.vue';
  import { useModalSlot } from 'vue-final-modal';
  import { createModal } from '@/services/createModal';
  const compateTableModal = createModal(
    CompareTable,
    'Protection Levels Comparison',
    '',
    'modal-container--fullScreen',
  );
  compateTableModal.patchOptions({
    slots: {
      default: useModalSlot({
        attrs: {
          onConfirm() {
            compateTableModal.close();
          },
        },
      }),
    },
  });
</script>

<style lang="scss">
  .configurator {
    @include media-sm-min {
      padding: 100px 0 !important;
    }
    &__title {
      @include media-sm-min {
        line-height: 55px !important;
      }
    }
    &-wrapper {
      text-align: center;
      display: flex;
      flex-direction: column;
      align-items: center;
      grid-gap: 20px;
      @include media-sm-min {
        flex-direction: row;
        align-items: stretch;
        grid-gap: 30px;
      }
    }
    &__block {
      width: 100%;
      padding: 20px;
      border-radius: 15px;
      border: 1px solid $mono-border;
    }
    &__technical {
      @include media-sm-min {
        flex: 1;
      }
      &-head {
        padding-bottom: 14px;
        border-bottom: 1px solid $mono-border;
        &-title {
          @include text(paragraph, normal, bold);
          font-weight: 600 !important;
          @include media-sm-min {
            @include text(paragraph, extralarge, bold);
          }
        }
      }
      &-title {
        display: flex;
        align-items: center;
        height: 30px;
        margin-bottom: 5px;
        @include text(paragraph, small, bold);
        font-weight: 600;
        line-height: 15px;
        span {
          &:not(:last-child) {
            margin-right: 5px;
          }
        }
        @include media-sm-min {
          @include text(paragraph, normal, bold);
        }
      }
      &-body {
        margin-top: 15px;
      }
      &-footer {
        margin-top: 15px;
        grid-gap: 15px;
        display: flex;
        flex-direction: column;
        @include media-sm-min {
          flex-direction: row;
          grid-gap: 20px;
          justify-content: space-between;
        }
        &-block {
          @include media-sm-min {
            width: 50%;
          }
        }
      }
    }
    &__bottom {
      margin-top: 20px;
      text-align: center;
      @include media-sm-min {
        margin-top: 40px;
      }
      &-ui-button {
        @include media-sm-min {
          height: auto;
        }
      }
    }
  }
</style>
