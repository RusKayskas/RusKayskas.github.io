<template>
  <div
    :class="[
      'compare-table__content-head',
      { 'compare-table__content-head--mobile': isMobile },
    ]"
  >
    <div v-show="!isMobile" class="compare-table__content-head-block">
      <span>Hide matches</span>
      <slot></slot>
    </div>
    <div class="compare-table__content-head-block">
      <p class="title">Basic</p>
      <p class="details">
        from <strong>&#36;{{ basicPrice }} </strong>
      </p>
      <p class="time">{{ timeSwitcher }}</p>
    </div>
    <div class="compare-table__content-head-block">
      <p class="title">Optimal</p>
      <p class="details">
        from <strong>&#36;{{ optimalPrice }} </strong>
      </p>
      <p class="time">{{ timeSwitcher }}</p>
    </div>
  </div>
</template>

<script setup>
  import { computed } from 'vue';
  const props = defineProps({
    isMobile: {
      type: Boolean,
      default: false,
    },
    priceSwitcher: {
      type: String,
      required: true,
    },
  });
  const basicPrice = computed(() => {
    return props.priceSwitcher === 'always' ? 450 : 200;
  });
  const optimalPrice = computed(() => {
    return props.priceSwitcher === 'always' ? 650 : 300;
  });
  const timeSwitcher = computed(() => {
    return props.priceSwitcher === 'always' ? 'monthly' : 'monthly package';
  });
</script>

<style lang="scss" scoped></style>
