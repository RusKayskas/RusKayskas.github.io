<template>
  <UiSection
    hasTitle
    id="experts"
    background="dark"
    class="experts ui-section--no-padding"
  >
    <template #text>
      <h2
        class="ui-section__text-title title title--section"
        v-html="experts.title"
      />
      <p class="ui-section__text-details">
        {{ experts.details }}
      </p>
      <UiButton
        :title="$t(experts.btn.title)"
        :id="experts.btn.id"
        @action="feedBackFormModal.open()"
      />
    </template>
    <template #content>
      <img
        :src="require(`@/assets/images/${experts.img}`)"
        :alt="experts.title"
        loading="lazy"
      />
    </template>
  </UiSection>
</template>

<script setup>
  import { useModalSlot } from 'vue-final-modal';
  //компоненты
  import { UiSection, UiButton } from '@/components/UI';
  import FeedbackForm from '@/components/common/FeedBackForm/index.vue';
  defineProps({
    experts: {
      type: Object,
      required: true,
    },
  });
  import { createModal } from '@/services/createModal';
  const feedBackFormModal = createModal(
    FeedbackForm,
    'Enterprise Level Protection',
    "Fill out this form, and we'll get back to you shortly",
  );
  feedBackFormModal.patchOptions({
    slots: {
      default: useModalSlot({
        attrs: {
          id: 'modal-enterprise-form-asia',
          buttonId: 'btn-lp-asia-enterprise-appform',
          emailId: 'lp-asia-enterprise-form-email',
          commentId: 'lp-asia-enterprise-form-message',
          buttonTitle: 'Submit request',
          onConfirm() {
            feedBackFormModal.close();
          },
        },
      }),
    },
  });
</script>

<style lang="scss">
  .experts {
    .ui-section__text {
      @include media-sm-min {
        padding: 100px 0;
      }
    }
    &.s-gradient {
      &::before {
        top: auto;
        width: 515.948px;
        height: 343.445px;
        border-radius: 515.948px;
        background: linear-gradient(
          301deg,
          #22377c 35.21%,
          rgba(233, 100, 255, 0.55) 33.8%,
          rgba(156, 102, 246, 0.69) 75.9%
        );
        right: -177.474px;
        opacity: 0.5;
        bottom: -124.675px;
        filter: blur(50px);
        @include media-xs-min {
          width: 661px;
          left: auto;
          transform: translate(0);
          height: 440px;
          right: -232px;
          bottom: -133px;
          background: linear-gradient(
            301deg,
            rgba(233, 100, 255, 0.55) 33.8%,
            #006be5 75.94%
          );
          opacity: 1;
          filter: blur(140px);
        }
      }
    }
    .ui-section__content {
      img {
        max-width: 290px;
        margin-bottom: 30px;
        @include media-sm-min {
          max-width: inherit;
          margin-bottom: 0;
        }
      }
    }
  }
</style>
