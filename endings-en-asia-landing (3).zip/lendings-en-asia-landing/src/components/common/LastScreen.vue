<template>
  <UiSection
    hasTitle
    background="dark"
    class="last-screen ui-section--no-padding"
  >
    <template #text>
      <h2
        class="ui-section__text-title title title--section"
        v-html="lastScreen.title"
      ></h2>
      <p class="ui-section__text-details">
        {{ lastScreen.details }}
      </p>
      <UiButton
        id="btn-lp-asia-lastscreen"
        :title="lastScreen.btn.title"
        tag="a"
        class="last-screen__ui-button"
        href="#configurator"
      />
    </template>
    <template #content>
      <img
        src="@/assets/images/asia/lastscreen/lastscreen.png"
        alt="lastScreen.title"
      />
    </template>
  </UiSection>
</template>

<script setup>
  import { UiSection, UiButton } from '@/components/UI';
  defineProps({
    lastScreen: {
      type: Object,
      required: true,
    },
  });
</script>

<style lang="scss">
  .last-screen {
    padding-bottom: 40px;
    padding-top: 60px;
    @include media-md-min {
      padding: 0;
      min-height: 385px;
      .ui-section-wrapper {
        align-items: flex-end;
      }
      .ui-section__text {
        margin: 100px 0;
      }
    }
    &.s-gradient {
      &::before {
        border-radius: 497px;
        background: linear-gradient(
          301deg,
          #22377c 50.21%,
          rgba(233, 100, 255, 0.55) 33.8%,
          rgba(156, 102, 246, 0.69) 75.9%
        );
        filter: blur(50px);
        right: -62px;
        transform: translate(0);
        top: auto;
        opacity: 0.6;
        left: auto;
        bottom: -50px;
        width: 497px;
        height: 330px;
        @include media-xs-min {
          border-radius: 661px;
          opacity: 1;
          background: linear-gradient(
            301deg,
            rgba(233, 100, 255, 0.55) 33.8%,
            #006be5 75.94%
          );

          filter: blur(140px);
          right: 255px;
          width: 661px;
          height: 440px;
          bottom: -235px;
        }
      }
    }
    .ui-section__content {
      img {
        max-width: 265px;
        @include media-md-min {
          max-width: unset;
        }
      }
    }
    &__ui-button {
      min-width: 170px;
      padding: 15px;
      @include media-sm-min {
        padding: 10px 15px;
        font-size: 18px;
      }
    }
  }
</style>
