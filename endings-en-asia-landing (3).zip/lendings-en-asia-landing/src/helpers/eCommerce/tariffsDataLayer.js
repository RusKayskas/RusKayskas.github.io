import dataLayer from './dataLayer';
import userCookie from './userCookie';
import { ecommerceData } from '@/page/asia/data';
export default class TariffsDataLayer {
  constructor(bandwidth, dynamicPrice, protectionType) {
    this.data = {
      ecommerce: {
        currencyCode: 'USD',
        customerCookie: userCookie(),
        customerId: '',
        add: {
          products: [
            {
              bandwidth: bandwidth,
              category: 'tunnel',
              id: ecommerceData.id,
              name: ecommerceData.name,
              price: dynamicPrice,
              protectionType: protectionType,
            },
          ],
        },
      },
      event: 'ecommerceAdd',
    };
  }

  push() {
    dataLayer({ ecommerce: null });
    dataLayer(this.data);
  }
}
