<template>
  <TheHeader :header="dataJson.header" />
  <div class="content">
    <AsiaBanner :banner="dataJson.asiaBanner" />
    <Advantages :benefits="dataJson.benefits" />
    <Table :table="dataJson.table" />
    <Configurator />
    <Experts :experts="dataJson.experts" />
    <WhyDdos :whyDdos="dataJson.whyDdos" />
    <Personal :personal="dataJson.personal" />
    <TwinTunnel :twinTunnel="dataJson.twinTunnel" />
    <Faq :faq="dataJson.faq" />
    <LastScreen :lastScreen="dataJson.lastScreen" />
  </div>
  <TheFooter :footer="dataJson.footer" />
  <UiCookieBanner />
  <ModalsContainer />
</template>

<script setup>
  import { ModalsContainer } from 'vue-final-modal';
  import dataJson from './data.json';

  import {
    TheHeader,
    AsiaBanner,
    Advantages,
    Table,
    Configurator,
    Experts,
    WhyDdos,
    Personal,
    TwinTunnel,
    Faq,
    LastScreen,
    TheFooter,
  } from '@/components/common';
  import UiCookieBanner from '@/components/UI/UiCookieBanner.vue';
</script>
